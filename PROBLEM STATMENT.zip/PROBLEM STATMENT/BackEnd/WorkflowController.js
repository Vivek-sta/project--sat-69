const asyncHandler = require('express-async-handler');



const workflow = new Workflow({
name: payload.name,
description: payload.description || '',
steps: payload.steps
});
const created = await workflow.save();
res.status(201).json(created);
;


// @desc Export workflow JSON
// @route GET /api/workflows/:id/export
// @access Public
const exportWorkflow = asyncHandler(async (req, res) => {
const workflow = await Workflow.findById(req.params.id);
if (!workflow) {
res.status(404);
throw new Error('Workflow not found');
}


res.setHeader('Content-Disposition', `attachment; filename="workflow-${workflow._id}.json"`);
res.setHeader('Content-Type', 'application/json');
res.send(JSON.stringify(workflow, null, 2));
});


// @desc Simulate execution of a workflow (server-side stub)
// @route POST /api/workflows/:id/execute
// @access Public
const executeWorkflow = asyncHandler(async (req, res) => {
const workflow = await Workflow.findById(req.params.id);
if (!workflow) {
res.status(404);
throw new Error('Workflow not found');
}


// A simple simulation example: iterate steps and return a report
const report = [];
for (let i = 0; i < workflow.steps.length; i++) {
const step = workflow.steps[i];
// Here you could add logic to validate steps, call external APIs, etc.
report.push({
step: i + 1,
type: step.type,
name: step.name || '',
status: 'success',
note: `Simulated execution of ${step.type}`
});
// Optional: insert delays or keep logs
}


res.json({ message: 'Execution simulated', report });
});


module.exports = {
getWorkflows,
createWorkflow,
getWorkflowById,
updateWorkflow,
deleteWorkflow,
importWorkflow,
exportWorkflow,
executeWorkflow
};