# AutoFlow Backend


## Requirements
- Node.js (v16+ recommended)
- MongoDB (local or Atlas)


## Install


1. Clone the repo
2. `cd autoflow-backend`
3. `npm install`
4. Copy `.env.example` to `.env` and adjust values


## Run (development)