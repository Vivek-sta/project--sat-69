require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const connectDB = require('E:\problem\BackEnd/config/db.js');
const workflowRoutes = require('E:\problem\BackEnd/Routes/WorkflowRoutes.js');
const errorHandler = require('E:\problem\BackEnd\Middleware/ErrorHandler.js');


const PORT = process.env.PORT || 4000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/autoflow';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';


// Connect DB
connectDB(MONGODB_URI);


const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));
app.use(cors({ origin: CORS_ORIGIN }));


// API routes
app.use('/api/workflows', WorkflowRoutes);


// Health check
app.get('/health', (req, res) => res.json({ status: 'ok' }));


// Error handling
app.use(ErrorHandler);


app.listen(PORT, () => {
console.log(`Server running on port ${PORT}`);
});


